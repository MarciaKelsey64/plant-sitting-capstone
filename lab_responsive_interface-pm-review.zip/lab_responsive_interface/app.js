// ==========================================
// 1. SELECT DOM ELEMENTS
// ==========================================
const input = document.getElementById('usernameInput');
const button = document.getElementById('searchBtn');
const results = document.getElementById('results');


// ==========================================
// 2. HELPER FUNCTION: RENDER THE UI
// ==========================================
// We extracted this to keep our fetch function clean!

// Please, don't use inline css!
// Add classes and then use CSS to target the elements
function renderProfileCard(data) {
    results.innerHTML = `
        <div style="text-align: left; width: 100%; animation: fadeIn 0.5s ease-in;">
            <img src="${data.avatar_url}" alt="Avatar" style="width: 80px; border-radius: 50%; float: left; margin-right: 15px;">
            <h3>${data.name || data.login}</h3>
            <p style="color: #666;">@${data.login}</p>
            <p style="margin-top: 10px;">${data.bio || 'No bio available for this user.'}</p>
            <p style="margin-top: 15px; font-size: 0.9rem;">
                <strong>Followers:</strong> ${data.followers} | <strong>Following:</strong> ${data.following}
            </p>
        </div>
    `;
}


// ==========================================
// 3. ACT: THE ASYNC FETCH FUNCTION
// ==========================================
async function fetchUser(username) {
    try {
        results.innerHTML = `<p class="placeholder-text">Loading data for <strong>${username}</strong>...</p>`;

        const response = await fetch(`https://api.github.com/users/${username}`);

        if (!response.ok) {
            throw new Error("User not found");
        }

        const data = await response.json();
        
        // Use our new helper function here!
        renderProfileCard(data);

    } catch (error) {
        results.innerHTML = `<p style="color: #d73a49; font-weight: bold;">Error: ${error.message}. Please check the spelling and try again.</p>`;
    }
}


// ==========================================
// 4. LISTEN: BUTTON CLICK OR ENTER KEY
// ==========================================
// Helper function to trigger the search
function handleSearch() {
    const username = input.value.trim();
    if (username) {
        fetchUser(username);
    } else {
        results.innerHTML = `<p style="color: #d73a49; font-weight: bold;">Please enter a valid username first!</p>`;
    }
}

// Listen for the Button Click
button.addEventListener('click', handleSearch);

// Listen for the Enter Key inside the input box
input.addEventListener('keypress', (event) => {
    if (event.key === 'Enter') {
        handleSearch();
    }
});